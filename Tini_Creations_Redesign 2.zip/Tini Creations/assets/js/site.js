/* Tini Creations — shop, cart, WhatsApp ordering and card checkout.
   Everything you are likely to change is in SETTINGS and CATALOGUE below. */

/* ======================================================================
   SETTINGS — edit these values
   ====================================================================== */
const SETTINGS = {
  // WhatsApp Business number in international format, digits only:
  // country code 27, then the number WITHOUT its leading 0.
  // Example: 084 899 2436 becomes "27848992436".
  whatsappNumber: "27605097417",

  // Card payments (Payfast).
  // testMode true  = Payfast sandbox, no real money moves.
  // testMode false = live payments using YOUR merchant ID and key below.
  payfast: {
    testMode: true,
    merchantId: "",   // your live Payfast merchant ID
    merchantKey: ""   // your live Payfast merchant key
  },

  // Order and contact emails are sent to this inbox through FormSubmit (free).
  // To use a different inbox, change the email address at the end of the link.
  orderEmailUrl: "https://formsubmit.co/ajax/nandimugwagwa@gmail.com",

  businessName: "Tini Creations"
};

/* ======================================================================
   CATALOGUE — names, prices and pictures
   Each option is one fixed price the customer can add to the cart.
   ====================================================================== */
const CLOTH = (low, high) => [
  { label: "Standard cloth", price: low },
  { label: "Premium cloth", price: high }
];
const HAT_CLOTH = (low, high) => [
  { label: "Normal cloth", price: low },
  { label: "Velvet", price: high }
];

const CATALOGUE = [
  { id: "waistcoat", group: "men", name: "Waistcoat", img: "waistcoat.jpg",
    desc: "Available in four colours. Tell us your colour in the order notes.",
    options: [{ label: "Standard", price: 350 }] },
  { id: "alb", group: "men", name: "Alb", img: "alb.jpg",
    desc: "Price depends on the quality and quantity of cloth.", options: CLOTH(350, 450) },
  { id: "cassock", group: "men", name: "Cassock", img: "cassock.jpg",
    desc: "With buttons or a zipper. Tell us which in the order notes.", options: CLOTH(850, 1500) },
  { id: "surplice", group: "men", name: "Surplice", img: "surplice.jpg",
    desc: "Price depends on the quality and quantity of cloth.", options: CLOTH(350, 450) },
  { id: "chasuble", group: "men", name: "Chasuble", img: "chasuble.jpg",
    desc: "Price depends on the cloth and trims.", options: CLOTH(350, 450) },
  { id: "dalmatic", group: "men", name: "Dalmatic", img: "dalmatic.jpg",
    desc: "Price depends on the cloth and trims.", options: CLOTH(350, 450) },
  { id: "stole", group: "men", name: "Stole", img: "stole.jpg",
    desc: "Price depends on the quality of cloth.", options: CLOTH(750, 800) },

  { id: "mini-hat", group: "women", name: "Mini hat", img: "mini-hat.jpg",
    desc: "Made in normal cloth or velvet.", options: HAT_CLOTH(100, 150) },
  { id: "hat", group: "women", name: "Hat", img: "hat.jpg",
    desc: "Made in normal cloth or velvet.", options: HAT_CLOTH(200, 250) },
  { id: "skirt", group: "women", name: "Skirt", img: "skirt.jpg",
    desc: "Price depends on the quality and quantity of cloth.", options: CLOTH(400, 450) },
  { id: "blouse", group: "women", name: "Blouse", img: "blouse.jpg",
    desc: "With or without a cape. Tell us which in the order notes.", options: CLOTH(400, 450) }
];

const ALTERATIONS = [
  { name: "Hemming pants", price: "R50 – R100", img: "hemming.jpg" },
  { name: "Taking seams in or out", price: "R100 – R200", img: "seams.jpg" },
  { name: "Zipper replacement", price: "R150 – R300", img: "zipper.jpg" }
];

/* ======================================================================
   Helpers
   ====================================================================== */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const rand = (n) => "R" + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const waLink = (text) => "https://wa.me/" + SETTINGS.whatsappNumber + (text ? "?text=" + encodeURIComponent(text) : "");
const productById = (id) => CATALOGUE.find((p) => p.id === id);

const store = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
    catch (e) { return fallback; }
  },
  set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* private mode */ } },
  remove(key) { try { localStorage.removeItem(key); } catch (e) { /* ignore */ } }
};

/* ======================================================================
   Cart
   ====================================================================== */
const CART_KEY = "tini-cart-v1";
const ORDER_KEY = "tini-last-order";

const cart = {
  lines: [],
  load() {
    const saved = store.get(CART_KEY, []);
    // Drop anything that no longer matches the catalogue (price or product changed).
    this.lines = (Array.isArray(saved) ? saved : []).filter((l) => {
      const p = productById(l.id);
      return p && p.options[l.opt] && Number.isInteger(l.qty) && l.qty > 0;
    });
  },
  save() { store.set(CART_KEY, this.lines); renderCart(); },
  add(id, opt, qty = 1) {
    const line = this.lines.find((l) => l.id === id && l.opt === opt);
    if (line) line.qty = Math.min(99, line.qty + qty);
    else this.lines.push({ id, opt, qty });
    this.save();
  },
  setQty(id, opt, qty) {
    const line = this.lines.find((l) => l.id === id && l.opt === opt);
    if (!line) return;
    if (qty <= 0) this.lines = this.lines.filter((l) => l !== line);
    else line.qty = Math.min(99, qty);
    this.save();
  },
  clear() { this.lines = []; this.save(); },
  detailed() {
    return this.lines.map((l) => {
      const p = productById(l.id), o = p.options[l.opt];
      return { ...l, name: p.name, img: p.img, option: o.label, single: p.options.length === 1, price: o.price, total: o.price * l.qty };
    });
  },
  count() { return this.lines.reduce((n, l) => n + l.qty, 0); },
  total() { return this.detailed().reduce((n, l) => n + l.total, 0); }
};

function lineHtml(l, editable) {
  const key = `data-id="${l.id}" data-opt="${l.opt}"`;
  return `<div class="cart-line">
    <img src="assets/img/products/${l.img}" alt="">
    <div>
      <div class="name">${esc(l.name)}</div>
      <div class="opt">${l.single ? "" : esc(l.option) + ", "}${rand(l.price)} each${editable ? "" : " × " + l.qty}</div>
      ${editable ? `<div class="qty">
        <button type="button" ${key} data-step="-1" aria-label="One less ${esc(l.name)}">−</button>
        <output aria-label="Quantity">${l.qty}</output>
        <button type="button" ${key} data-step="1" aria-label="One more ${esc(l.name)}">+</button>
      </div>
      <button type="button" class="link-btn remove" ${key} data-step="remove">Remove</button>` : ""}
    </div>
    <div class="line-total">${rand(l.total)}</div>
  </div>`;
}

function renderCart() {
  const lines = cart.detailed(), count = cart.count();
  $$("[data-cart-count]").forEach((el) => { el.textContent = count; el.dataset.empty = String(count === 0); });

  const body = $("#cart-lines");
  if (body) {
    body.innerHTML = lines.length
      ? lines.map((l) => lineHtml(l, true)).join("")
      : `<p class="empty">Your cart is empty.<br><a href="shop.html">Browse the garments</a></p>`;
    $("#cart-foot").hidden = lines.length === 0;
    $("#cart-total").textContent = rand(cart.total());
    $("#cart-whatsapp").href = waLink(orderMessage(null));
  }
  renderCheckoutSummary();
}

function initCartDrawer() {
  const drawer = $("#cart-drawer");
  if (!drawer) return;
  $$("[data-open-cart]").forEach((b) => b.addEventListener("click", () => drawer.showModal()));
  $("#cart-close").addEventListener("click", () => drawer.close());
  drawer.addEventListener("click", (e) => { if (e.target === drawer) drawer.close(); });
  drawer.addEventListener("click", (e) => {
    const b = e.target.closest("[data-step]");
    if (!b) return;
    const id = b.dataset.id, opt = Number(b.dataset.opt);
    const line = cart.lines.find((l) => l.id === id && l.opt === opt);
    if (!line) return;
    cart.setQty(id, opt, b.dataset.step === "remove" ? 0 : line.qty + Number(b.dataset.step));
  });
}

/* ======================================================================
   WhatsApp order message
   ====================================================================== */
function orderMessage(details) {
  const lines = cart.detailed();
  const out = [`Hello ${SETTINGS.businessName}, I would like to place an order.`, ""];
  if (details && details.ref) out.push(`Order ref: ${details.ref}`);
  lines.forEach((l, i) => out.push(`${i + 1}. ${l.qty} x ${l.name}${l.single ? "" : " (" + l.option + ")"} = ${rand(l.total)}`));
  out.push("", `Total: ${rand(cart.total())}`);
  if (details) {
    out.push("", `Name: ${details.name}`, `Phone: ${details.phone}`);
    if (details.email) out.push(`Email: ${details.email}`);
    out.push(`Receive by: ${details.fulfilment}`);
    if (details.address) out.push(`Delivery address: ${details.address}`);
    if (details.notes) out.push(`Notes: ${details.notes}`);
    if (details.paid) out.push("", details.paid);
  }
  return out.join("\n");
}

/* ======================================================================
   Shop page
   ====================================================================== */
function initShop() {
  $$("[data-products]").forEach((grid) => {
    grid.innerHTML = CATALOGUE.filter((p) => p.group === grid.dataset.products).map((p) => {
      const multi = p.options.length > 1;
      return `<article class="product" data-id="${p.id}">
        <div class="product-img"><img src="assets/img/products/${p.img}" alt="${esc(p.name)}" loading="lazy"></div>
        <div class="product-body">
          <h3>${esc(p.name)}</h3>
          <p>${esc(p.desc)}</p>
          ${multi ? `<label class="visually-hidden" for="opt-${p.id}">Cloth for ${esc(p.name)}</label>
          <select id="opt-${p.id}">${p.options.map((o, i) => `<option value="${i}">${esc(o.label)} (${rand(o.price)})</option>`).join("")}</select>` : ""}
          <div class="price" data-price>${rand(p.options[0].price)}</div>
          <button type="button" class="btn btn-primary btn-block" data-add>Add to cart</button>
          <div class="added" role="status" aria-live="polite"></div>
        </div>
      </article>`;
    }).join("");
  });

  document.addEventListener("change", (e) => {
    const card = e.target.closest(".product");
    if (!card || e.target.tagName !== "SELECT") return;
    const p = productById(card.dataset.id);
    $("[data-price]", card).textContent = rand(p.options[Number(e.target.value)].price);
  });

  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-add]");
    if (!btn) return;
    const card = btn.closest(".product"), sel = $("select", card);
    cart.add(card.dataset.id, sel ? Number(sel.value) : 0);
    const note = $(".added", card);
    note.innerHTML = `Added to cart. <button type="button" class="link-btn" data-open-cart-inline>View cart</button>`;
    clearTimeout(note._t);
    note._t = setTimeout(() => { note.textContent = ""; }, 6000);
  });

  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-open-cart-inline]")) $("#cart-drawer").showModal();
  });

  const list = $("#alteration-list");
  if (list) {
    list.innerHTML = ALTERATIONS.map((a) => `<li>
      <img src="assets/img/alterations/${a.img}" alt="" loading="lazy">
      <div><h3>${esc(a.name)}</h3><p>The price depends on how much work the alteration needs.</p></div>
      <div class="price">${a.price}</div>
      <a class="btn btn-whatsapp" target="_blank" rel="noopener" href="${waLink(`Hello ${SETTINGS.businessName}, I would like to book an alteration: ${a.name}. When can I bring my item in?`)}">${WA_ICON}Book on WhatsApp</a>
    </li>`).join("");
  }
}

/* ======================================================================
   Checkout page
   ====================================================================== */
function renderCheckoutSummary() {
  const box = $("#checkout-summary");
  if (!box) return;
  const lines = cart.detailed(), empty = lines.length === 0;
  box.innerHTML = empty ? "" : lines.map((l) => lineHtml(l, false)).join("");
  $("#checkout-total").textContent = rand(cart.total());
  $("#checkout-empty").hidden = !empty;
  $("#checkout-main").hidden = empty;
  const pay = $("#pay-card");
  if (pay) pay.textContent = `Pay ${rand(cart.total())} by card`;
}

function newRef() {
  const d = new Date(), pad = (n) => String(n).padStart(2, "0");
  return "TC-" + String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
}

function readCheckoutForm(form) {
  const f = new FormData(form);
  const delivery = f.get("fulfilment") === "delivery";
  return {
    ref: newRef(),
    name: String(f.get("name") || "").trim(),
    phone: String(f.get("phone") || "").trim(),
    email: String(f.get("email") || "").trim(),
    fulfilment: delivery ? "Delivery (courier cost to be quoted)" : "Collection from the workshop",
    address: delivery ? String(f.get("address") || "").trim() : "",
    notes: String(f.get("notes") || "").trim()
  };
}

async function emailOrder(details, method) {
  // Sends the full order to the business inbox. Never blocks the customer for long.
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 5000);
  try {
    await fetch(SETTINGS.orderEmailUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      signal: ctrl.signal,
      body: JSON.stringify({
        _subject: `New order ${details.ref} (${method})`,
        _template: "table",
        name: details.name, phone: details.phone, email: details.email || undefined,
        order: orderMessage(details), total: rand(cart.total()), payment: method
      })
    });
  } catch (e) { /* the order still reaches you through Payfast or WhatsApp */ }
  clearTimeout(timer);
}

function payfastSubmit(details) {
  const pf = SETTINGS.payfast, live = !pf.testMode;
  const lines = cart.detailed();
  const summary = lines.map((l) => `${l.qty} x ${l.name}${l.single ? "" : " (" + l.option + ")"}`).join("; ");
  const [first, ...rest] = details.name.split(/\s+/);
  const here = /^https?:$/.test(location.protocol);

  const fields = {
    merchant_id: live ? pf.merchantId : "10000100",
    merchant_key: live ? pf.merchantKey : "46f0cd694581a",
    return_url: here ? new URL("order-complete.html?paid=1", location.href).href : "",
    cancel_url: here ? new URL("checkout.html?cancelled=1", location.href).href : "",
    name_first: first.slice(0, 100),
    name_last: rest.join(" ").slice(0, 100),
    email_address: details.email,
    m_payment_id: details.ref,
    amount: cart.total().toFixed(2),
    item_name: `${SETTINGS.businessName} order ${details.ref}`.slice(0, 100),
    item_description: summary.slice(0, 255),
    custom_str1: details.phone.slice(0, 255),
    custom_str2: (details.fulfilment + (details.address ? ": " + details.address : "")).slice(0, 255),
    custom_str3: details.notes.slice(0, 255)
  };

  const form = document.createElement("form");
  form.method = "post";
  form.action = live ? "https://www.payfast.co.za/eng/process" : "https://sandbox.payfast.co.za/eng/process";
  Object.entries(fields).forEach(([k, v]) => {
    if (!v) return;
    const i = document.createElement("input");
    i.type = "hidden"; i.name = k; i.value = v;
    form.appendChild(i);
  });
  document.body.appendChild(form);
  form.submit();
}

function initCheckout() {
  const form = $("#checkout-form");
  if (!form) return;

  const pf = SETTINGS.payfast;
  $("#test-notice").hidden = !pf.testMode;

  const addressField = $("#address-field");
  const syncAddress = () => {
    const delivery = form.fulfilment.value === "delivery";
    addressField.hidden = !delivery;
    form.address.required = delivery;
  };
  form.addEventListener("change", syncAddress);
  syncAddress();

  const status = $("#checkout-status");
  const say = (msg, kind) => { status.textContent = msg; status.className = "form-status " + kind; };

  if (new URLSearchParams(location.search).has("cancelled")) {
    say("The card payment was cancelled and you have not been charged. Your cart is still here.", "err");
  }

  const validate = () => {
    if (cart.count() === 0) { say("Your cart is empty. Add a garment before you check out.", "err"); return null; }
    if (!form.reportValidity()) return null;
    return readCheckoutForm(form);
  };

  $("#pay-card").addEventListener("click", async (e) => {
    const details = validate();
    if (!details) return;
    if (!pf.testMode && (!pf.merchantId || !pf.merchantKey)) {
      say("Card payments are not set up yet. Send your order on WhatsApp instead.", "err");
      return;
    }
    e.currentTarget.disabled = true;
    say("Taking you to the secure Payfast payment page…", "ok");
    store.set(ORDER_KEY, { ...details, method: "card", total: cart.total(), message: orderMessage({ ...details, paid: "Paid by card on the website." }) });
    await emailOrder(details, "card via Payfast");
    payfastSubmit(details);
  });

  // Re-enable the button if the customer comes back from Payfast with the back button.
  window.addEventListener("pageshow", () => { $("#pay-card").disabled = false; });

  $("#pay-whatsapp").addEventListener("click", () => {
    const details = validate();
    if (!details) return;
    const message = orderMessage(details);
    // Open WhatsApp straight away so the browser does not block the new tab.
    window.open(waLink(message), "_blank", "noopener");
    store.set(ORDER_KEY, { ...details, method: "whatsapp", total: cart.total(), message });
    emailOrder(details, "WhatsApp");
    location.href = "order-complete.html";
  });
}

/* ======================================================================
   Order complete page
   ====================================================================== */
function initOrderComplete() {
  const box = $("#order-complete");
  if (!box) return;
  const order = store.get(ORDER_KEY, null);
  const paid = new URLSearchParams(location.search).has("paid");
  // A card order only counts once Payfast has sent the customer back here.
  if (!order || (order.method === "card" && !paid)) { $("#no-order").hidden = false; return; }

  cart.clear();
  box.hidden = false;
  $("#order-ref").textContent = order.ref;
  $("#order-total").textContent = rand(order.total);
  $("#order-heading").textContent = order.method === "card" && paid ? "Thank you. Your payment went through." : "Your order is on its way to us.";
  $("#order-next").textContent = order.method === "card" && paid
    ? "We will confirm your order on WhatsApp once the payment reflects, and arrange your measurements."
    : "Press send in WhatsApp if you have not already. We will reply to confirm the order and arrange your measurements.";
  $("#order-whatsapp").href = waLink(order.message);
  $("#order-whatsapp-label").textContent = order.method === "card" ? "Send us your order details on WhatsApp" : "Open the WhatsApp message again";
}

/* ======================================================================
   Contact form, navigation, WhatsApp links
   ====================================================================== */
function initContactForm() {
  const form = $("#contact-form");
  if (!form) return;
  const status = $("#contact-status");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("button[type=submit]", form);
    btn.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(form));
      data._subject = "Website message: " + (data.subject || "no subject");
      const res = await fetch(SETTINGS.orderEmailUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(data)
      });
      const reply = await res.json().catch(() => ({}));
      if (!res.ok || String(reply.success) === "false") throw new Error("failed");
      form.reset();
      status.textContent = "Message sent. We will get back to you soon.";
      status.className = "form-status ok";
    } catch (err) {
      status.textContent = "The message could not be sent. Check your connection and send it again, or message us on WhatsApp.";
      status.className = "form-status err";
    }
    btn.disabled = false;
  });
}

const WA_ICON = `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.9-4.45 9.9-9.91A9.86 9.86 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.82c0 4.54-3.7 8.23-8.23 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.16.25-.64.81-.78.97-.14.17-.29.19-.54.06a6.7 6.7 0 0 1-1.99-1.23 7.4 7.4 0 0 1-1.38-1.72c-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.16-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.11-.22-.17-.47-.29Z"/></svg>`;

function initChrome() {
  const toggle = $(".nav-toggle"), nav = $("#site-nav");
  if (toggle) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    nav.addEventListener("click", (e) => { if (e.target.tagName === "A") { nav.classList.remove("open"); toggle.setAttribute("aria-expanded", "false"); } });
  }
  // Any link marked data-wa opens a WhatsApp chat with the business number.
  $$("[data-wa]").forEach((a) => {
    a.href = waLink(a.dataset.wa || `Hello ${SETTINGS.businessName}, I would like to place an order.`);
    a.target = "_blank"; a.rel = "noopener";
  });
  $$("[data-wa-icon]").forEach((el) => el.insertAdjacentHTML("afterbegin", WA_ICON));
  $$("[data-year]").forEach((el) => { el.textContent = new Date().getFullYear(); });
}

document.addEventListener("DOMContentLoaded", () => {
  cart.load();
  initChrome();
  initCartDrawer();
  initShop();
  initCheckout();
  initOrderComplete();
  initContactForm();
  renderCart();
});

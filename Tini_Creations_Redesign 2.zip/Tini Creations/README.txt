TINI CREATIONS WEBSITE
======================

Pages
  index.html           Home, about, services, portfolio, team, contact
  shop.html            Garments with cart, and alterations (booked on WhatsApp)
  checkout.html        Customer details, card payment or WhatsApp order
  order-complete.html  Confirmation page after an order

Everything you are likely to change is at the top of assets/js/site.js:
SETTINGS (WhatsApp number, Payfast, email form) and CATALOGUE (products, prices).


1. WHATSAPP NUMBER
------------------
SETTINGS.whatsappNumber must be digits only: 27, then the number without its
leading 0. Example: 084 899 2436 becomes "27848992436".

It is set to "27605097417" (060 509 7417). Every WhatsApp button on the site
uses it.


2. CARD PAYMENTS (PAYFAST)
--------------------------
The site ships in TEST MODE: it uses Payfast's public sandbox account, so the
whole flow can be tried without real money. The checkout page shows a
"test mode" notice while this is on.

To take real payments:
  a. Open a merchant account at payfast.io and get it verified.
  b. In the Payfast dashboard, copy your Merchant ID and Merchant Key.
  c. In assets/js/site.js set:
         testMode: false,
         merchantId: "your id",
         merchantKey: "your key"
  d. Leave the Payfast "passphrase" security setting OFF. This site has no
     server, so it cannot sign payments with a passphrase.
  e. Upload the site to your web hosting (it must be on https) and make one
     small real payment to check it end to end.

Important: the site is static (no server), so the amount is sent to Payfast
from the customer's browser. Before you start sewing, check that the amount
on the Payfast payment notification matches the order total in the order
email. If you later want this checked automatically, a developer can add a
small server script (Payfast calls it "ITN").


3. ORDER EMAILS
---------------
Each order (card or WhatsApp) and each contact message is emailed to
nandimugwagwa@gmail.com through FormSubmit, a free service that needs no
account (SETTINGS.orderEmailUrl in site.js).

ONE-TIME STEP: after the site is online, send one test message from the
contact form. FormSubmit emails an "Activate form" link to that inbox (check
spam). Click it once. Until it is clicked, no emails are delivered.

Emails cannot be sent to a WhatsApp number. WhatsApp orders reach your
WhatsApp directly through the buttons on the site.

Card orders also show in your Payfast dashboard with the order reference,
items, phone number and notes.


4. PRICES
---------
The old site showed price ranges (for example R350-R450). A cart needs one
price per item, so each garment now has two choices: the lower price as
"Standard cloth" and the higher price as "Premium cloth" (hats: "Normal
cloth" and "Velvet"). Change the labels or prices in CATALOGUE in site.js.

Delivery is not charged online. Customers can choose delivery and you quote
the courier cost on WhatsApp.
